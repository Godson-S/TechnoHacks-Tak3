# TechnoHacks_Task3
Visualization using Histogram, Here i ve super store dataset and performed visualization
